# No custom keep rules required; R8 will keep components referenced from the manifest.
