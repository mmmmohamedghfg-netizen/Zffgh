package com.example.clockwidgets

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.util.Log
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

class ClockWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_REFRESH_DYNAMIC = "com.example.clockwidgets.ACTION_REFRESH_DYNAMIC"
        const val ACTION_WIDGET_PINNED = "com.example.clockwidgets.ACTION_WIDGET_PINNED"
        const val EXTRA_STYLE_ID = "extra_style_id"

        private const val TAG = "ClockWidgetProvider"
        private const val REFRESH_INTERVAL_MS = 15_000L
        private const val REFRESH_REQUEST_CODE = 1001
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.Main).launch {
            try {
                for (id in appWidgetIds) {
                    val settings = WidgetPrefs.load(context, id)
                    manager.updateAppWidget(id, buildRemoteViews(context, id, settings))
                }
                scheduleDynamicRefresh(context)
            } catch (e: Exception) {
                Log.e(TAG, "onUpdate failed", e)
            } finally {
                pendingResult.finish()
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)

        when (intent.action) {
            ACTION_REFRESH_DYNAMIC -> {
                val pendingResult = goAsync()
                CoroutineScope(Dispatchers.Main).launch {
                    try {
                        refreshDynamicWidgets(context)
                    } catch (e: Exception) {
                        Log.e(TAG, "Dynamic refresh failed", e)
                    } finally {
                        pendingResult.finish()
                    }
                }
            }

            ACTION_WIDGET_PINNED -> {
                val widgetId = intent.getIntExtra(
                    AppWidgetManager.EXTRA_APPWIDGET_ID,
                    AppWidgetManager.INVALID_APPWIDGET_ID
                )
                val styleId = intent.getIntExtra(EXTRA_STYLE_ID, 1)

                if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) return

                val pendingResult = goAsync()
                CoroutineScope(Dispatchers.Main).launch {
                    try {
                        WidgetPrefs.save(context, widgetId, WidgetSettings(styleId = styleId))
                        val manager = AppWidgetManager.getInstance(context)
                        val settings = WidgetPrefs.load(context, widgetId)
                        manager.updateAppWidget(widgetId, buildRemoteViews(context, widgetId, settings))
                        scheduleDynamicRefresh(context)
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to apply pinned widget style", e)
                    } finally {
                        pendingResult.finish()
                    }
                }
            }
        }
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.Main).launch {
            try {
                appWidgetIds.forEach { WidgetPrefs.save(context, it, WidgetSettings()) }
                scheduleDynamicRefresh(context)
            } catch (e: Exception) {
                Log.e(TAG, "onDeleted failed", e)
            } finally {
                pendingResult.finish()
            }
        }
    }

    override fun onEnabled(context: Context) {
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.Main).launch {
            try {
                scheduleDynamicRefresh(context)
            } finally {
                pendingResult.finish()
            }
        }
    }

    override fun onDisabled(context: Context) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.cancel(dynamicRefreshPendingIntent(context))
    }

    private suspend fun refreshDynamicWidgets(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, ClockWidgetProvider::class.java))

        for (id in ids) {
            val settings = WidgetPrefs.load(context, id)
            val style = WidgetStyles.byId(settings.styleId)

            if (WidgetStyles.isDynamic(style.mode)) {
                manager.updateAppWidget(id, buildRemoteViews(context, id, settings))
            }
        }

        scheduleDynamicRefresh(context)
    }

    private suspend fun scheduleDynamicRefresh(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, ClockWidgetProvider::class.java))

        val hasDynamicWidget = ids.any { id ->
            val settings = WidgetPrefs.load(context, id)
            WidgetStyles.isDynamic(WidgetStyles.byId(settings.styleId).mode)
        }

        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pendingIntent = dynamicRefreshPendingIntent(context)
        alarm.cancel(pendingIntent)

        if (hasDynamicWidget) {
            alarm.setAndAllowWhileIdle(
                AlarmManager.ELAPSED_REALTIME,
                System.currentTimeMillis() + REFRESH_INTERVAL_MS,
                pendingIntent
            )
        }
    }

    private fun dynamicRefreshPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, ClockWidgetProvider::class.java).apply {
            action = ACTION_REFRESH_DYNAMIC
        }

        return PendingIntent.getBroadcast(
            context,
            REFRESH_REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun buildRemoteViews(
        context: Context,
        appWidgetId: Int,
        settings: WidgetSettings
    ): RemoteViews {
        val style = WidgetStyles.byId(settings.styleId)
        val rv = RemoteViews(context.packageName, R.layout.widget_clock)

        val textColor = if (settings.textColor != -1) settings.textColor else style.textColor
        val accentColor = if (settings.accentColor != -1) settings.accentColor else style.accentColor
        val font = settings.font.ifEmpty { style.font }
        val scale = if (settings.sizeScale > 0f) settings.sizeScale else style.sizeScale
        val alpha = settings.transparency.coerceIn(0.15f, 1f)
        val finalTextColor = applyAlpha(textColor, alpha)
        val finalAccentColor = applyAlpha(accentColor, alpha)

        rv.setInt(R.id.widget_root, "setBackgroundResource", style.backgroundRes)

        applyFont(rv, R.id.text_time, font)
        applyFont(rv, R.id.text_flip, font)
        applyFont(rv, R.id.text_words, font)
        applyFont(rv, R.id.text_binary, "monospace")

        rv.setTextColor(R.id.text_time, finalTextColor)
        rv.setTextColor(R.id.text_date, finalTextColor)
        rv.setTextColor(R.id.text_day, finalTextColor)
        rv.setTextColor(R.id.text_hijri, finalTextColor)
        rv.setTextColor(R.id.text_battery, finalTextColor)
        rv.setTextColor(R.id.text_weather, finalTextColor)
        rv.setTextColor(R.id.text_alarm, finalTextColor)
        rv.setTextColor(R.id.text_flip, finalAccentColor)
        rv.setTextColor(R.id.text_words, finalTextColor)
        rv.setTextColor(R.id.text_binary, finalAccentColor)
        rv.setTextColor(R.id.text_world1, finalTextColor)
        rv.setTextColor(R.id.text_world2, finalTextColor)
        rv.setTextColor(R.id.text_world3, finalTextColor)

        val baseSize = 38f * scale
        rv.setTextViewTextSize(R.id.text_time, TypedValue.COMPLEX_UNIT_SP, baseSize)
        rv.setTextViewTextSize(R.id.text_flip, TypedValue.COMPLEX_UNIT_SP, baseSize * 0.85f)
        rv.setTextViewTextSize(R.id.text_words, TypedValue.COMPLEX_UNIT_SP, baseSize * 0.55f)
        rv.setTextViewTextSize(R.id.text_binary, TypedValue.COMPLEX_UNIT_SP, baseSize * 0.45f)

        val showSeconds = settings.showSeconds ?: style.showSeconds
        val showDate = settings.showDate ?: style.showDate
        val showHijri = settings.showHijri ?: style.showHijri
        val showDay = settings.showDay ?: style.showDay
        val showBattery = settings.showBattery ?: style.showBattery
        val showWeather = settings.showWeather ?: style.showWeather
        val showAlarm = settings.showAlarm ?: style.showAlarm

        val timePattern = if (style.mode == WidgetMode.DIGITAL && showSeconds) {
            if (style.time24.contains("ss")) {
                style.time24
            } else {
                style.time24.replace("mm", "mm:ss")
            }
        } else {
            style.time24
        }

        rv.setString(R.id.text_time, "setFormat24Hour", timePattern)
        rv.setString(R.id.text_time, "setFormat12Hour", style.time12)

        visibility(rv, R.id.analog_container, style.mode == WidgetMode.ANALOG)
        visibility(rv, R.id.text_time, style.mode == WidgetMode.DIGITAL)
        visibility(rv, R.id.text_flip, style.mode == WidgetMode.FLIP)
        visibility(rv, R.id.text_binary, style.mode == WidgetMode.BINARY)
        visibility(rv, R.id.text_words, style.mode == WidgetMode.WORDS)
        visibility(rv, R.id.date_box, showDate || showDay)
        visibility(rv, R.id.text_date, showDate)
        visibility(rv, R.id.text_day, showDay)
        visibility(rv, R.id.text_hijri, showHijri)

        val showInfo = showBattery || showWeather || showAlarm
        visibility(rv, R.id.info_box, showInfo)
        visibility(rv, R.id.text_battery, showBattery)
        visibility(rv, R.id.text_weather, showWeather)
        visibility(rv, R.id.text_alarm, showAlarm)
        visibility(rv, R.id.world_box, style.mode == WidgetMode.WORLD)

        if (style.mode == WidgetMode.ANALOG) {
            rv.setInt(R.id.analog_dial, "setImageResource", style.analogDial)
        }

        if (style.mode == WidgetMode.FLIP) {
            val now = Calendar.getInstance()
            val hour = String.format("%02d", now.get(Calendar.HOUR_OF_DAY))
            val minute = String.format("%02d", now.get(Calendar.MINUTE))
            rv.setTextViewText(R.id.text_flip, "$hour\n$minute")
        }

        if (style.mode == WidgetMode.BINARY) {
            rv.setTextViewText(R.id.text_binary, binaryTimeText())
        }

        if (style.mode == WidgetMode.WORDS) {
            rv.setTextViewText(R.id.text_words, ArabicTimeWords.now())
        }

        if (showBattery) {
            rv.setTextViewText(R.id.text_battery, batteryText(context))
        }

        if (showWeather) {
            if (appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val weather = WidgetPrefs.weatherText(context)
                        val updated = RemoteViews(context.packageName, R.layout.widget_clock).apply {
                            setTextViewText(
                                R.id.text_weather,
                                weather.ifEmpty { context.getString(R.string.weather_na) }
                            )
                        }
                        AppWidgetManager.getInstance(context).updateAppWidget(appWidgetId, updated)
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to update weather text", e)
                    }
                }
            } else {
                rv.setTextViewText(R.id.text_weather, context.getString(R.string.weather_na))
            }
        }

        if (showAlarm) {
            rv.setTextViewText(R.id.text_alarm, nextAlarmText(context))
        }

        if (style.mode == WidgetMode.WORLD) {
            val labels = listOf("الرياض", "لندن", "نيويورك")

            style.worldZones.forEachIndexed { index, zone ->
                val viewId = when (index) {
                    0 -> R.id.text_world1
                    1 -> R.id.text_world2
                    else -> R.id.text_world3
                }

                rv.setString(viewId, "setTimeZone", zone)
                rv.setTextViewText(viewId, "${labels[index]} •")
            }
        }

        return rv
    }

    private fun visibility(rv: RemoteViews, viewId: Int, visible: Boolean) {
        rv.setViewVisibility(viewId, if (visible) View.VISIBLE else View.GONE)
    }

    private fun applyFont(rv: RemoteViews, viewId: Int, font: String) {
        val typeface = when (font) {
            "sans-serif-light" -> Typeface.create("sans-serif-light", Typeface.NORMAL)
            "sans-serif-medium" -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
            "sans-serif-black" -> Typeface.create("sans-serif-black", Typeface.BOLD)
            "monospace" -> Typeface.MONOSPACE
            "serif" -> Typeface.SERIF
            else -> Typeface.SANS_SERIF
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            rv.setTextViewTextTypeface(viewId, typeface)
        }
    }

    private fun applyAlpha(color: Int, alpha: Float): Int {
        val newAlpha = (Color.alpha(color) * alpha).toInt().coerceIn(0, 255)
        return Color.argb(newAlpha, Color.red(color), Color.green(color), Color.blue(color))
    }

    private fun batteryText(context: Context): String {
        val intent = context.registerReceiver(
            null,
            android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED)
        )

        val level = intent?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100) ?: 100

        if (level < 0 || scale <= 0) return "البطارية: غير متاح"

        val percent = (level * 100) / scale
        return "البطارية: $percent%"
    }

    private fun nextAlarmText(context: Context): String {
        val manager = context.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
        val alarm = manager.nextAlarmClock ?: return "لا يوجد منبه"

        val time = android.text.format.DateFormat.getTimeFormat(context).format(alarm.triggerTime)
        return "المنبه: $time"
    }

    private fun binaryTimeText(): String {
        val now = Calendar.getInstance()
        val hour = now.get(Calendar.HOUR_OF_DAY)
        val minute = now.get(Calendar.MINUTE)
        return "${toBinaryRow(hour)}\n${toBinaryRow(minute)}"
    }

    private fun toBinaryRow(value: Int): String {
        return Integer.toBinaryString(value)
            .padStart(6, '0')
            .map { if (it == '1') "●" else "○" }
            .joinToString(" ")
    }
}
