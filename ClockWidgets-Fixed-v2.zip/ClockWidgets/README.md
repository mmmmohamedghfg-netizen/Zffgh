# ساعات ويدجت — Clock Widgets

مشروع أندرويد Kotlin لويدجتات ساعة متعددة الأنماط.

## البناء محليًا
```bash
gradle wrapper
./gradlew assembleDebug
```

الـ APK:
`app/build/outputs/apk/debug/app-debug.apk`

## الرفع على GitHub بدون فك ضغط المشروع
ارفع `ClockWidgets.zip` إلى جذر المستودع، ثم أنشئ:
`.github/workflows/build-apk.yml`
والصق فيه محتوى ملف الـ workflow المرفق.
