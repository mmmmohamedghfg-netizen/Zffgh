package com.example.clockwidgets

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recycler = findViewById<RecyclerView>(R.id.recycler_styles)
        recycler.layoutManager = GridLayoutManager(this, 2)
        recycler.adapter = StyleAdapter { style ->
            val intent = Intent(this, ClockWidgetConfigActivity::class.java)
            intent.putExtra(ClockWidgetConfigActivity.EXTRA_STYLE_ID, style.id)
            startActivity(intent)
        }
    }
}
