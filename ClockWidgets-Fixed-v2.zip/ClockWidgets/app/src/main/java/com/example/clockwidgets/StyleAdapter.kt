package com.example.clockwidgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.RemoteViews
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class StyleAdapter(
    private val onCustomize: (WidgetStyle) -> Unit
) : RecyclerView.Adapter<StyleAdapter.StyleViewHolder>() {

    private val styles = WidgetStyles.all

    class StyleViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val preview: FrameLayout = view.findViewById(R.id.preview_container)
        val name: TextView = view.findViewById(R.id.text_style_name)
        val add: View = view.findViewById(R.id.button_add)
        val customize: View = view.findViewById(R.id.button_customize)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StyleViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_style, parent, false)
        return StyleViewHolder(view)
    }

    override fun onBindViewHolder(holder: StyleViewHolder, position: Int) {
        val context = holder.itemView.context
        val style = styles[position]

        holder.name.text = style.name
        holder.preview.removeAllViews()

        val remoteViews = ClockWidgetProvider().buildRemoteViews(
            context,
            AppWidgetManager.INVALID_APPWIDGET_ID,
            WidgetSettings(styleId = style.id)
        )

        try {
            remoteViews.apply(context, holder.preview)
        } catch (_: Exception) {
            holder.preview.setBackgroundColor(0x22000000)
        }

        holder.add.setOnClickListener {
            val manager = AppWidgetManager.getInstance(context)
            val provider = ComponentName(context, ClockWidgetProvider::class.java)

            if (!manager.isRequestPinAppWidgetSupported) {
                Toast.makeText(
                    context,
                    context.getString(R.string.pin_not_supported),
                    Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }

            val callbackIntent = Intent(context, ClockWidgetProvider::class.java).apply {
                action = ClockWidgetProvider.ACTION_WIDGET_PINNED
                putExtra(ClockWidgetProvider.EXTRA_STYLE_ID, style.id)
            }

            val callback = PendingIntent.getBroadcast(
                context,
                style.id,
                callbackIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            manager.requestPinAppWidget(provider, null, callback)
        }

        holder.customize.setOnClickListener { onCustomize(style) }
    }

    override fun getItemCount(): Int = styles.size
}
