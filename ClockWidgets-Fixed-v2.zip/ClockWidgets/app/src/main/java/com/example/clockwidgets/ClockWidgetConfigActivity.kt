package com.example.clockwidgets

import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.switchmaterial.SwitchMaterial
import kotlinx.coroutines.launch

class ClockWidgetConfigActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_STYLE_ID = "extra_style_id"
        const val EXTRA_APPWIDGET_ID = "app_widget_id"
    }

    private var appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private var isPreviewOnly = false

    private var currentStyleId = 1
    private var currentTextColor = Color.WHITE
    private var currentFont = "sans-serif"
    private var currentSize = 1.0f
    private var currentTransparency = 1.0f
    private var currentRadius = 20

    private lateinit var preview: FrameLayout
    private lateinit var spinnerStyle: Spinner
    private lateinit var spinnerFont: Spinner
    private lateinit var spinnerColor: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        setContentView(R.layout.activity_config)

        appWidgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID

        val styleIdFromGallery = intent?.extras?.getInt(EXTRA_STYLE_ID, -1) ?: -1

        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            if (styleIdFromGallery == -1) {
                finish()
                return
            }

            isPreviewOnly = true
            currentStyleId = styleIdFromGallery

            findViewById<View>(R.id.text_preview_mode).visibility = View.VISIBLE
            findViewById<View>(R.id.button_save).isEnabled = false
        }

        preview = findViewById(R.id.preview_container)
        spinnerStyle = findViewById(R.id.spinner_style)
        spinnerFont = findViewById(R.id.spinner_font)
        spinnerColor = findViewById(R.id.spinner_color)

        setupSpinners()
        setupSeekBars()
        setupSwitches()
        setupButtons()

        if (!isPreviewOnly) {
            lifecycleScope.launch {
                val saved = WidgetPrefs.load(this@ClockWidgetConfigActivity, appWidgetId)
                currentStyleId = saved.styleId
                if (saved.textColor != -1) currentTextColor = saved.textColor
                if (saved.font.isNotEmpty()) currentFont = saved.font
                if (saved.sizeScale > 0f) currentSize = saved.sizeScale
                if (saved.transparency > 0f) currentTransparency = saved.transparency
                if (saved.cornerRadius > 0) currentRadius = saved.cornerRadius

                spinnerStyle.setSelection(
                    WidgetStyles.all.indexOfFirst { it.id == currentStyleId }.coerceAtLeast(0)
                )
                updatePreview()
            }
        } else {
            spinnerStyle.setSelection(
                WidgetStyles.all.indexOfFirst { it.id == currentStyleId }.coerceAtLeast(0)
            )
            updatePreview()
        }
    }

    private fun setupSpinners() {
        val styleNames = WidgetStyles.all.map { it.name }
        spinnerStyle.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            styleNames
        )

        spinnerStyle.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                currentStyleId = WidgetStyles.all[position].id
                updatePreview()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }

        val fonts = listOf(
            "sans-serif" to "افتراضي",
            "sans-serif-light" to "خفيف",
            "sans-serif-medium" to "متوسط",
            "sans-serif" to "عريض",
            "monospace" to "أحادي المسافة",
            "serif" to "Serif"
        )

        spinnerFont.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            fonts.map { it.second }
        )

        spinnerFont.setSelection(fonts.indexOfFirst { it.first == currentFont }.coerceAtLeast(0))

        spinnerFont.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                currentFont = fonts[position].first
                updatePreview()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }

        val colors = listOf(
            "أبيض" to Color.WHITE,
            "أسود" to Color.BLACK,
            "أزرق" to Color.parseColor("#4F8CFF"),
            "بنفسجي" to Color.parseColor("#B388FF"),
            "أخضر نيون" to Color.parseColor("#39FF14"),
            "وردي نيون" to Color.parseColor("#FF2D95")
        )

        spinnerColor.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            colors.map { it.first }
        )

        spinnerColor.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                currentTextColor = colors[position].second
                updatePreview()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
    }

    private fun setupSeekBars() {
        findViewById<SeekBar>(R.id.seek_size).setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                    currentSize = 0.6f + progress / 100f * 1.4f
                    updatePreview()
                }

                override fun onStartTrackingTouch(bar: SeekBar?) = Unit
                override fun onStopTrackingTouch(bar: SeekBar?) = Unit
            }
        )

        findViewById<SeekBar>(R.id.seek_transparency).setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                    currentTransparency = 0.15f + progress / 100f * 0.85f
                    updatePreview()
                }

                override fun onStartTrackingTouch(bar: SeekBar?) = Unit
                override fun onStopTrackingTouch(bar: SeekBar?) = Unit
            }
        )

        findViewById<SeekBar>(R.id.seek_radius).setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                    currentRadius = 4 + progress / 4
                    updatePreview()
                }

                override fun onStartTrackingTouch(bar: SeekBar?) = Unit
                override fun onStopTrackingTouch(bar: SeekBar?) = Unit
            }
        )
    }

    private fun setupSwitches() {
        findViewById<SwitchMaterial>(R.id.switch_seconds).setOnCheckedChangeListener { _, _ -> updatePreview() }
        findViewById<SwitchMaterial>(R.id.switch_date).setOnCheckedChangeListener { _, _ -> updatePreview() }
        findViewById<SwitchMaterial>(R.id.switch_hijri).setOnCheckedChangeListener { _, _ -> updatePreview() }
        findViewById<SwitchMaterial>(R.id.switch_day).setOnCheckedChangeListener { _, _ -> updatePreview() }
        findViewById<SwitchMaterial>(R.id.switch_battery).setOnCheckedChangeListener { _, _ -> updatePreview() }
        findViewById<SwitchMaterial>(R.id.switch_weather).setOnCheckedChangeListener { _, _ -> updatePreview() }
        findViewById<SwitchMaterial>(R.id.switch_alarm).setOnCheckedChangeListener { _, _ -> updatePreview() }
    }

    private fun setupButtons() {
        findViewById<View>(R.id.button_weather).setOnClickListener {
            val city = findViewById<EditText>(R.id.input_city).text.toString().ifEmpty { "الرياض" }
            val lat = findViewById<EditText>(R.id.input_lat).text.toString().toDoubleOrNull() ?: 24.7136
            val lon = findViewById<EditText>(R.id.input_lon).text.toString().toDoubleOrNull() ?: 46.6753

            lifecycleScope.launch {
                WidgetPrefs.saveWeatherLocation(this@ClockWidgetConfigActivity, city, lat, lon)
                WeatherWorker.enqueueNow(this@ClockWidgetConfigActivity)
                Toast.makeText(this@ClockWidgetConfigActivity, "جاري تحديث الطقس", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<View>(R.id.button_save).setOnClickListener {
            if (isPreviewOnly) return@setOnClickListener

            val settings = currentSettings()

            lifecycleScope.launch {
                WidgetPrefs.save(this@ClockWidgetConfigActivity, appWidgetId, settings)

                val manager = AppWidgetManager.getInstance(this@ClockWidgetConfigActivity)
                manager.updateAppWidget(
                    appWidgetId,
                    ClockWidgetProvider().buildRemoteViews(
                        this@ClockWidgetConfigActivity,
                        appWidgetId,
                        settings
                    )
                )

                if (settings.showWeather == true) {
                    WeatherWorker.enqueuePeriodic(this@ClockWidgetConfigActivity)
                }

                Toast.makeText(
                    this@ClockWidgetConfigActivity,
                    getString(R.string.saved),
                    Toast.LENGTH_SHORT
                ).show()

                setResult(RESULT_OK, Intent().putExtra(EXTRA_APPWIDGET_ID, appWidgetId))
                finish()
            }
        }
    }

    private fun currentSettings(): WidgetSettings = WidgetSettings(
        styleId = currentStyleId,
        textColor = currentTextColor,
        accentColor = currentTextColor,
        font = currentFont,
        sizeScale = currentSize,
        transparency = currentTransparency,
        cornerRadius = currentRadius,
        showSeconds = findViewById<SwitchMaterial>(R.id.switch_seconds).isChecked,
        showDate = findViewById<SwitchMaterial>(R.id.switch_date).isChecked,
        showHijri = findViewById<SwitchMaterial>(R.id.switch_hijri).isChecked,
        showDay = findViewById<SwitchMaterial>(R.id.switch_day).isChecked,
        showBattery = findViewById<SwitchMaterial>(R.id.switch_battery).isChecked,
        showWeather = findViewById<SwitchMaterial>(R.id.switch_weather).isChecked,
        showAlarm = findViewById<SwitchMaterial>(R.id.switch_alarm).isChecked
    )

    private fun updatePreview() {
        preview.removeAllViews()

        try {
            ClockWidgetProvider().buildRemoteViews(
                this,
                AppWidgetManager.INVALID_APPWIDGET_ID,
                currentSettings()
            ).apply(this, preview)
        } catch (_: Exception) {
            preview.setBackgroundColor(0x22000000)
        }
    }
}
