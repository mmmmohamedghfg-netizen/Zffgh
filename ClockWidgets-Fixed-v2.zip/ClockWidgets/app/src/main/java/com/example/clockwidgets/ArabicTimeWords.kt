package com.example.clockwidgets

import java.util.Calendar

object ArabicTimeWords {

    private val hours = arrayOf(
        "الثانية عشرة", "الأولى", "الثانية", "الثالثة", "الرابعة", "الخامسة",
        "السادسة", "السابعة", "الثامنة", "التاسعة", "العاشرة", "الحادية عشرة"
    )

    fun now(): String {
        val calendar = Calendar.getInstance()
        val hour24 = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)
        val hour12 = if (hour24 == 0 || hour24 == 12) 0 else hour24 % 12
        val hourName = hours[hour12]

        return when (minute) {
            0 -> "$hourName تمامًا"
            15 -> "الربع و$hourName"
            30 -> "النصف و$hourName"
            45 -> "الربع إلا $hourName"
            else -> "$hourName و$minute دقيقة"
        }
    }
}
