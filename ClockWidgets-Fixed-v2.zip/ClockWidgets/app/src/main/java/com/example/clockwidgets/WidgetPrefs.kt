package com.example.clockwidgets

import android.content.Context
import android.util.Log
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import org.json.JSONObject

private val Context.dataStore by preferencesDataStore(name = "widget_settings")

data class WidgetSettings(
    val styleId: Int = 1,
    val textColor: Int = -1,
    val accentColor: Int = -1,
    val font: String = "",
    val sizeScale: Float = -1f,
    val transparency: Float = 1f,
    val cornerRadius: Int = -1,
    val showSeconds: Boolean? = null,
    val showDate: Boolean? = null,
    val showHijri: Boolean? = null,
    val showDay: Boolean? = null,
    val showBattery: Boolean? = null,
    val showWeather: Boolean? = null,
    val showAlarm: Boolean? = null
)

object WidgetPrefs {

    private const val TAG = "WidgetPrefs"

    private fun key(widgetId: Int) = stringPreferencesKey("widget_$widgetId")
    private val weatherTextKey = stringPreferencesKey("weather_text")
    private val weatherCityKey = stringPreferencesKey("weather_city")
    private val weatherLatKey = stringPreferencesKey("weather_lat")
    private val weatherLonKey = stringPreferencesKey("weather_lon")

    suspend fun save(context: Context, widgetId: Int, settings: WidgetSettings) {
        val json = JSONObject().apply {
            put("styleId", settings.styleId)
            put("textColor", settings.textColor)
            put("accentColor", settings.accentColor)
            put("font", settings.font)
            put("sizeScale", settings.sizeScale.toDouble())
            put("transparency", settings.transparency.toDouble())
            put("cornerRadius", settings.cornerRadius)
            settings.showSeconds?.let { put("showSeconds", it) }
            settings.showDate?.let { put("showDate", it) }
            settings.showHijri?.let { put("showHijri", it) }
            settings.showDay?.let { put("showDay", it) }
            settings.showBattery?.let { put("showBattery", it) }
            settings.showWeather?.let { put("showWeather", it) }
            settings.showAlarm?.let { put("showAlarm", it) }
        }

        context.dataStore.edit { it[key(widgetId)] = json.toString() }
    }

    suspend fun load(context: Context, widgetId: Int): WidgetSettings {
        val raw = context.dataStore.data.first()[key(widgetId)] ?: return WidgetSettings()

        return try {
            val json = JSONObject(raw)
            WidgetSettings(
                styleId = json.optInt("styleId", 1),
                textColor = json.optInt("textColor", -1),
                accentColor = json.optInt("accentColor", -1),
                font = json.optString("font", ""),
                sizeScale = json.optDouble("sizeScale", -1.0).toFloat(),
                transparency = json.optDouble("transparency", 1.0).toFloat(),
                cornerRadius = json.optInt("cornerRadius", -1),
                showSeconds = if (json.has("showSeconds")) json.getBoolean("showSeconds") else null,
                showDate = if (json.has("showDate")) json.getBoolean("showDate") else null,
                showHijri = if (json.has("showHijri")) json.getBoolean("showHijri") else null,
                showDay = if (json.has("showDay")) json.getBoolean("showDay") else null,
                showBattery = if (json.has("showBattery")) json.getBoolean("showBattery") else null,
                showWeather = if (json.has("showWeather")) json.getBoolean("showWeather") else null,
                showAlarm = if (json.has("showAlarm")) json.getBoolean("showAlarm") else null
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse widget settings for widget $widgetId", e)
            WidgetSettings()
        }
    }

    suspend fun saveWeather(context: Context, text: String) {
        context.dataStore.edit { it[weatherTextKey] = text }
    }

    suspend fun weatherText(context: Context): String =
        context.dataStore.data.first()[weatherTextKey] ?: ""

    suspend fun saveWeatherLocation(context: Context, city: String, lat: Double, lon: Double) {
        context.dataStore.edit {
            it[weatherCityKey] = city
            it[weatherLatKey] = lat.toString()
            it[weatherLonKey] = lon.toString()
        }
    }

    suspend fun weatherLocation(context: Context): Triple<String, Double, Double> {
        val prefs = context.dataStore.data.first()
        val city = prefs[weatherCityKey] ?: "الرياض"
        val lat = prefs[weatherLatKey]?.toDoubleOrNull() ?: 24.7136
        val lon = prefs[weatherLonKey]?.toDoubleOrNull() ?: 46.6753
        return Triple(city, lat, lon)
    }
}
