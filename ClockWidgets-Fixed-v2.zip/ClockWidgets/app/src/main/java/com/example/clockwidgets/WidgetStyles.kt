package com.example.clockwidgets

import android.graphics.Color

enum class WidgetMode { DIGITAL, ANALOG, FLIP, BINARY, WORDS, WORLD }

data class WidgetStyle(
    val id: Int,
    val name: String,
    val mode: WidgetMode,
    val time24: String = "HH:mm",
    val time12: String = "h:mm a",
    val showSeconds: Boolean = false,
    val showDate: Boolean = false,
    val showHijri: Boolean = false,
    val showDay: Boolean = false,
    val showBattery: Boolean = false,
    val showWeather: Boolean = false,
    val showAlarm: Boolean = false,
    val analogDial: Int = R.drawable.dial_classic,
    val backgroundRes: Int = R.drawable.bg_card,
    val textColor: Int = Color.WHITE,
    val accentColor: Int = Color.WHITE,
    val font: String = "sans-serif",
    val sizeScale: Float = 1.0f,
    val worldZones: List<String> = emptyList()
)

object WidgetStyles {

    val all: List<WidgetStyle> = listOf(
        WidgetStyle(1, "رقمية بسيطة", WidgetMode.DIGITAL),
        WidgetStyle(2, "رقمية كبيرة", WidgetMode.DIGITAL, sizeScale = 1.5f),
        WidgetStyle(3, "نيون", WidgetMode.DIGITAL,
            backgroundRes = R.drawable.bg_neon,
            textColor = Color.parseColor("#39FF14"),
            accentColor = Color.parseColor("#39FF14"),
            font = "monospace"),
        WidgetStyle(4, "رقمية بالثواني", WidgetMode.DIGITAL, "HH:mm:ss", "h:mm:ss a", showSeconds = true),
        WidgetStyle(5, "نظام 12 ساعة", WidgetMode.DIGITAL, "hh:mm a", "hh:mm a"),
        WidgetStyle(6, "نظام 24 ساعة", WidgetMode.DIGITAL),
        WidgetStyle(7, "تناظرية كلاسيك", WidgetMode.ANALOG),
        WidgetStyle(8, "تناظرية مودرن", WidgetMode.ANALOG, analogDial = R.drawable.dial_modern),
        WidgetStyle(9, "تناظرية مينيمال", WidgetMode.ANALOG, analogDial = R.drawable.dial_minimal),
        WidgetStyle(10, "تناظرية رومانية", WidgetMode.ANALOG, analogDial = R.drawable.dial_roman),
        WidgetStyle(11, "ساعة وتاريخ", WidgetMode.DIGITAL, showDate = true),
        WidgetStyle(12, "ساعة هجرية", WidgetMode.DIGITAL, showHijri = true),
        WidgetStyle(13, "ساعة واسم اليوم", WidgetMode.DIGITAL, showDay = true),
        WidgetStyle(14, "ساعة وطقس", WidgetMode.DIGITAL, showWeather = true),
        WidgetStyle(15, "ساعة وبطارية", WidgetMode.DIGITAL, showBattery = true),
        WidgetStyle(16, "شفافة", WidgetMode.DIGITAL, backgroundRes = R.drawable.bg_transparent),
        WidgetStyle(17, "زجاجية", WidgetMode.DIGITAL, backgroundRes = R.drawable.bg_glass),
        WidgetStyle(18, "تدرج أزرق", WidgetMode.DIGITAL, backgroundRes = R.drawable.bg_gradient_blue),
        WidgetStyle(19, "فليب", WidgetMode.FLIP, font = "sans-serif", sizeScale = 1.2f),
        WidgetStyle(20, "ثنائية Binary", WidgetMode.BINARY, font = "monospace"),
        WidgetStyle(21, "ساعة كلمات", WidgetMode.WORDS, sizeScale = 1.1f),
        WidgetStyle(22, "ساعات عالمية", WidgetMode.WORLD,
            worldZones = listOf("Asia/Riyadh", "Europe/London", "America/New_York"))
    )

    fun byId(id: Int): WidgetStyle = all.firstOrNull { it.id == id } ?: all.first()

    fun isDynamic(mode: WidgetMode): Boolean =
        mode == WidgetMode.FLIP || mode == WidgetMode.BINARY || mode == WidgetMode.WORDS
}
