package com.example.clockwidgets

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

class WeatherWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val (city, lat, lon) = WidgetPrefs.weatherLocation(applicationContext)
        val url = URL(
            "https://api.open-meteo.com/v1/forecast" +
                    "?latitude=$lat&longitude=$lon&current_weather=true"
        )

        val connection = url.openConnection() as HttpURLConnection

        try {
            connection.connectTimeout = 8000
            connection.readTimeout = 8000
            connection.requestMethod = "GET"

            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val current = JSONObject(body).getJSONObject("current_weather")
            val temperature = current.getDouble("temperature")
            val code = current.getInt("weathercode")

            WidgetPrefs.saveWeather(
                applicationContext,
                "$city: ${weatherDescription(code)}، $temperature°C"
            )

            Result.success()
        } catch (_: Exception) {
            if (runAttemptCount >= 3) Result.failure() else Result.retry()
        } finally {
            connection.disconnect()
        }
    }

    private fun weatherDescription(code: Int): String = when (code) {
        0 -> "صافٍ"
        in 1..3 -> "غائم جزئيًا"
        in 45..48 -> "ضباب"
        in 51..67 -> "مطر"
        in 71..77 -> "ثلج"
        in 80..82 -> "زخات مطر"
        in 95..99 -> "عواصف رعدية"
        else -> "طقس متغير"
    }

    companion object {
        private const val WORK_NAME = "clock_widget_weather"

        fun enqueueNow(context: Context) {
            val request = OneTimeWorkRequestBuilder<WeatherWorker>().build()
            WorkManager.getInstance(context)
                .enqueueUniqueWork(WORK_NAME, ExistingWorkPolicy.REPLACE, request)
        }

        fun enqueuePeriodic(context: Context) {
            val request = PeriodicWorkRequestBuilder<WeatherWorker>(30, TimeUnit.MINUTES).build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )
        }
    }
}
