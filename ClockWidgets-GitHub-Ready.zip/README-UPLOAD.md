# رفع المشروع على GitHub بدون فك ضغط مشروع الأندرويد

ارفع إلى الجذر الرئيسي للمستودع:

1. `ClockWidgets.zip`
2. `.github/workflows/build-apk.yml`

على GitHub:
- Add file > Upload files > ارفع `ClockWidgets.zip`
- Add file > Create new file > اكتب `.github/workflows/build-apk.yml`
- الصق محتوى ملف الـ workflow ثم Commit.
- من تبويب Actions شغّل Build Android APK.
- حمّل APK من Artifacts.

الـ workflow يفك ضغط `ClockWidgets.zip` تلقائيًا ويبني APK بـ Gradle 8.2.
